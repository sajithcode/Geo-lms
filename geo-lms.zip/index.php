<?php
// Root index.php - Redirect to login page
header("Location: auth/index.php");
exit;
?>