<?php
// includes/footer.php
?>
    </div> 
</body>
</html>